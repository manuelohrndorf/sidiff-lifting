package org.sidiff.domains.library.editrules;

import org.sidiff.difference.rulebase.extension.AbstractProjectRuleBase;

/**
 * This generated class does not add any functionality to the @link{AbstractProjectRuleBase}
 * and conforms to the structure needed in such a @link{RuleBaseProjectNature}.
 * @generated
 * @see AbstractProjectRuleBase
 * @see IRuleBase
 *
 */
public class ProjectRuleBase extends AbstractProjectRuleBase {

}
