package agg.gui.event;

import java.util.EventListener;

public interface TypeEventListener extends EventListener {

	/**
	 * TypeEvent occurred
	 */
	public void typeEventOccurred(TypeEvent e);
}
