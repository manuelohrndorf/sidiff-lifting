package agg.gui.event;

import java.util.EventListener;

public interface SaveEventListener extends EventListener {

	/**
	 * SaveEvent occurred
	 */
	public void saveEventOccurred(SaveEvent e);
}
