/**
 * 
 */
package agg.gui.editor;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

/**
 * @author olga
 *
 */
public class GraphMorphismEditorMouseMotionAdapter implements MouseMotionListener {

	private final GraphMorphismEditor editor;
	
	public GraphMorphismEditorMouseMotionAdapter(final GraphMorphismEditor editor) {
		this.editor = editor;
		this.editor.addMouseMotionListener(this);
	}
	
	public void mouseMoved(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
	}

}
