/**
 * 
 */
package agg.layout;

import org.eclipse.zest.layouts.algorithms.SpringLayoutAlgorithm;

/**
 * @author olga
 *
 */
public class AggSpringLayoutAlgorithm extends SpringLayoutAlgorithm {

	
	public AggSpringLayoutAlgorithm() {
		super();
	}
	
	public AggSpringLayoutAlgorithm(int styles) {
		super(styles);
	}
	
}
